matlab -nodisplay -r "run('switch_between_experiments.m');exit"
