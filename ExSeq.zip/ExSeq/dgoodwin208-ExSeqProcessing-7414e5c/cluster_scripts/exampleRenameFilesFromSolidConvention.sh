matlab -nodisplay -logfile ../logs/File_renaming_from_solidformat.log -r "run('../experiment_specific_scripts/copy_scope_names_to_reg_names.m')" 
