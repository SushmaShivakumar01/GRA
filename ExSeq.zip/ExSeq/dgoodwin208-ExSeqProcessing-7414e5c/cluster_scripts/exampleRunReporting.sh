matlab -nodisplay -r "reporting_registration({'summedNorm_registered'});exit;" 
