function vol = load3DTif_uint16(path)
    vol = double(read_file(path));
end
