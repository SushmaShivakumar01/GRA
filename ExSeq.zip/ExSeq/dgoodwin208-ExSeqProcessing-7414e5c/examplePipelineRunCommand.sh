./runPipeline.sh  -N 8 -b splintr3F2 -B 1 #-s "color-correction" #R /home/dgoodwin/ExSeqRepo/registration/
#./runPipeline.sh  -N 8 -b splintr3F2 -c "'ch00','ch01','ch02','ch03'" -B 1 #-s "color-correction" #R /home/dgoodwin/ExSeqRepo/registration/

#./runPipeline.sh  -N 20 -b exseqautoframe7 -c "'ch00','ch01SHIFT','ch02SHIFT','ch03SHIFT'" -R /home/dgoodwin/ExSeqRepo/registration/ -B 5 -s "color-correction,normalization,puncta-extraction"
#./runPipeline.sh  -N 20 -b exseqautoframe7 -c "'ch00','ch01SHIFT','ch02SHIFT','ch03SHIFT'" -R /home/dgoodwin/ExSeqRepo/registration/ -B 5 -s "color-correction,normalization,puncta-extraction"
