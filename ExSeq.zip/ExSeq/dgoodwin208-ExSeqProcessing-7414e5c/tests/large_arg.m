function large_arg(pix)
    s = pix(1,1,1);
end
